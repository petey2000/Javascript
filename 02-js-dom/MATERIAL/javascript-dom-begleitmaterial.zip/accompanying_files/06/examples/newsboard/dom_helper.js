'use strict'

const $ = q => document.querySelector(q)
