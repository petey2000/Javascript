'use strict'
const moment = require('moment')
console.log(moment().day('Saturday').format('DD.MM.YYYY'))
