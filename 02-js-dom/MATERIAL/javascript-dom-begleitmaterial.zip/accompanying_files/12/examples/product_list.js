'use strict'

const PRODUCTS = [
    { name: '3Doodler 3D Printing Pen', price: 29.99 },
    { name: 'Powerstation 5- E. Maximus Chargus', price: 44.95 },
    { name: '8-Bit Legendary Hero Heat-Change Mug', price: 6.99 },
]
