'use strict'

{
    const init = () => {}

    init()
}
