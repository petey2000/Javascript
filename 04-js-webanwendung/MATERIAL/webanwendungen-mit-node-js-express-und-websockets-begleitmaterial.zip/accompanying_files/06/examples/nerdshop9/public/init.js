const $ = document.querySelector.bind(document)
const $$ = document.querySelectorAll.bind(document)

viewProductList()
